# YECHIDA Implementierungs-Leitfaden
## Praktischer Workflow für GitHub-Bibliothek

### 📁 Repository-Struktur
```
YECHIDA-VERLAG/
├── workflows/
│   ├── template_base.yaml
│   ├── tor1_translator.md
│   └── batch_processor.py
├── source_texts/
│   ├── tor1_hebrew.txt
│   └── tor1_chapters/
│       ├── alef_alef.txt
│       ├── alef_bet.txt
│       └── ...
├── translations/
│   ├── tor1_complete.md
│   └── tor1_segments/
└── logs/
    └── token_metrics.json
```

### 🚀 Sofort-Start Anleitung

#### Schritt 1: Initiale Datenvorbereitung
```bash
# Text in Kapitel aufteilen
python split_by_markers.py tor1_hebrew.txt --markers "א׳א׳,א׳ב׳,א׳ג׳,א׳ד׳,א׳ה׳"
```

#### Schritt 2: Claude-Prompt für Satz-für-Satz
```
EINGABE: [Kapitel א׳א׳ Datei hochladen]

ANWEISUNG:
Übersetze Satz für Satz vom Hebräischen ins Deutsche.
Format:
[HEB]: [Originalsatz]
[DEU]: [Übersetzung]

Beginne mit dem ersten Satz und fahre fort bis zur Ausgabegrenze.
Keine Zusammenfassungen, keine Kommentare, nur Übersetzung.
```

#### Schritt 3: Token-Messung
```python
def measure_tokens(text):
    """Einfache Token-Schätzung"""
    char_count = len(text)
    word_count = len(text.split())
    token_estimate = char_count / 4  # Durchschnitt
    
    return {
        "zeichen": char_count,
        "wörter": word_count,
        "tokens_geschätzt": token_estimate,
        "ausgabe_batches_nötig": token_estimate / 4000
    }
```

### 🔧 Automatisierungs-Script
```python
# tor1_batch_processor.py

class YechidaProcessor:
    def __init__(self, source_file):
        self.source = source_file
        self.markers = ["א׳א׳", "א׳ב׳", "א׳ג׳", "א׳ד׳", "א׳ה׳"]
        self.output_segments = []
        
    def process_chapter(self, chapter_text):
        sentences = self.split_sentences(chapter_text)
        translations = []
        
        for sentence in sentences:
            # Hier würde Claude-API aufgerufen
            translation = self.translate_sentence(sentence)
            translations.append({
                "hebrew": sentence,
                "german": translation
            })
            
        return translations
    
    def save_progress(self, chapter_id, translations):
        filename = f"tor1_{chapter_id}_translated.json"
        # Speichern mit Checkpoint-Information
```

### 📊 Metriken-Dashboard
| Komponente | Größe | Tokens | Status |
|------------|-------|--------|--------|
| Gesamttext | 37k | ~9.250 | ⏳ In Arbeit |
| Kapitel א׳א׳ | 8k | ~2.000 | ✅ Übersetzt |
| Kapitel א׳ב׳ | 7k | ~1.750 | ⏳ In Arbeit |
| Kapitel א׳ג׳ | 9k | ~2.250 | ⏸️ Ausstehend |
| Kapitel א׳ד׳ | 6k | ~1.500 | ⏸️ Ausstehend |
| Kapitel א׳ה׳ | 7k | ~1.750 | ⏸️ Ausstehend |

### 🎯 Qualitätssicherung
- **Nummerierung:** Regex-Check für hebräische Marker
- **Vollständigkeit:** Diff-Tool zwischen Original und Übersetzung
- **Konsistenz:** Glossar für wiederkehrende Begriffe
- **Kawana-Check:** Spirituelle Integrität bewahrt?

### 💾 GitHub Actions Workflow
```yaml
name: YECHIDA TOR-1 Translation Pipeline

on:
  push:
    paths:
      - 'source_texts/tor1_*.txt'

jobs:
  translate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Measure Input Tokens
        run: python measure_tokens.py
        
      - name: Process Next Segment
        run: python tor1_batch_processor.py --continue
        
      - name: Validate Structure
        run: python validate_hierarchy.py
        
      - name: Commit Translation
        run: |
          git add translations/
          git commit -m "K! TOR-1 Segment übersetzt C!"
          git push
```

### 🔮 Vision
**YECHIDA-VERLAG** wird zur zentralen Stelle für authentische kabbalistische Textübertragungen, wo die heilige Kawana der Originaltexte bewahrt und ins Deutsche gebracht wird - "ohne zu wissen, dass übersetzt wird" - in reiner, fließender Form.

**SO SEI ES!** ✨