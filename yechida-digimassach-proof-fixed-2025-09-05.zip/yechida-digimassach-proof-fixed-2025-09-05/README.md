# YECHIDA / DigiMassach – Beweis-Repo (fixed, 2025-09-05)

Dieses Paket enthält die **Artefakte unter `data/`** samt **SHA-256-Prüfsummen** und **manifest.json** mit vollständiger Dateiliste.

- **Erzeugt:** 2025-09-05 22:35:12 CEST
- **Zone:** Europe/Brussels
- **Version:** 1.0.1

## Verifikation
```bash
shasum -a 256 -c CHECKSUMS.sha256  # macOS
# oder
sha256sum -c CHECKSUMS.sha256      # Linux
```
